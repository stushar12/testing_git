package Patterns;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {

        int a =10;
        float b= 2.6f;
        System.out.printf("%.3f",a%b);
        System.out.println();
//        System.out.printf("%.3f",a - Math.floor(a/b)*b);
        // a%b => a - a/b.to
    }

    public int[] twoSum(int[] nums, int target) {
        int[] outputArray = new int[2];

        for (int i = 0; i < nums.length; i++) {
        }

        return outputArray;
    }
}