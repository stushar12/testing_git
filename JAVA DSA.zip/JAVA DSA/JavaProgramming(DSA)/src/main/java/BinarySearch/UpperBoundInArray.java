package BinarySearch;

public class UpperBoundInArray {
    public static void main(String[] args) {
        /*upper bound for a sorted array is to find the smallest index where value at that index is greater than the given value*/
        int[] arr = {2, 4, 6, 8, 8, 8, 11, 13};
        int x = 8;
        System.out.println("Upper bound index for the given array is : " + upperBound(arr, arr.length, x));
    }

    static int upperBound(int[] arr, int n, int x) {
        int low = 0;
        int high = n - 1;
        int ans = n;
        while (low <= high) {
            int mid = (low + high) / 2;
            if (arr[mid] > x) {
                ans = mid;
                high = mid - 1;
            } else {
                low = mid + 1;
            }
        }

        return ans;
    }
}
